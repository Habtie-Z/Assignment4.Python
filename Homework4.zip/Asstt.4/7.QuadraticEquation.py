from math import sqrt
class QuadraticEquation:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    def getDiscriminant(self):
        return (self.b**2 - 4*self.a*self.c)
    def getRoot1(self): 
        d=self.getDiscriminant()
        if(d<0):
            return 0
        elif (d >0):
            return ((-b + sqrt(d))/(2*a)) 
        else:
            return -b/(2*a)
    def getRoot2(self):
        d=self.getDiscriminant()
        if(d <0):
            return 0
        elif(d>0):
            return((-b - sqrt(d))/(2*a)) 
        else:
            return -b/(2*a)

a=float(input("Enter a: "))
b=float(input("Enter b: "))
c=float(input("Enter c: "))
q1 = QuadraticEquation(a,b,c)
if(q1.getDiscriminant() >0):
    print("The quadratic equation has two roots: root1 =", q1.getRoot1(), end = " " + " and ")
    print("root2 =", q1.getRoot2())
elif(q1.getDiscriminant() == 0):
    print("The  quadratic equation has one root: x = ",q1.getRoot1())
else:
    print("The  quadratic equation has no roots")



    


