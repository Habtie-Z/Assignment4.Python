class Rectangle():
    def __init__(self,width,height):
        self.width = width
        self.height = height
    
    def getArea(self):
       area = self.width * self.height
       return area
    
    def getPerimeter(self):
       perimeter = 2*(self.width + self.height)
       return perimeter

w1=float(input("Enter width of rectangle 1: "))
h1=float(input("Enter height of rectangle 1: "))

Rec1=Rectangle(w1,h1)
A1 = "Area of rectangle 1 is {:.2f}."
print(A1.format(Rec1.getArea()))

print("Perimeter of rectangle 1:", Rec1.getPerimeter())

w2=float(input("Enter width of rectangle 2: "))
h2=float(input("Enter height of rectangle 2: "))

Rec2=Rectangle(w2,h2)

A2 = "Area of rectangle 2 is {:.2f}."
print(A2.format(Rec2.getArea()))

print("Perimeter of rectangle 2:", Rec2.getPerimeter())