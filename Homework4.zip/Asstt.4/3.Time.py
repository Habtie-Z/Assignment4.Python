class Time:
  
    def __init__(self, hours=0, minutes=0, seconds=0):
  
        self.hours = hours
        self.minutes = minutes
        self.seconds = seconds

    def __str__(self):
    
        return str(self.hours) + ':' + str(self.minutes) + ':' + str(self.seconds)

    def clean(self):
       
        if self.seconds < 60:
            return
        else:
            self.minutes = int(self.seconds/60)+self.minutes
            self.seconds = self.seconds%60
        if self.minutes < 60:
            return
        else:
            self.hours = int(self.minutes/60)+ self.hours
            self.minutes = self.minutes%60            
        return self.__str__()

    def to_seconds(self):
      
        minutes = self.hours * 60 + self.minutes
        seconds = minutes * 60 + self.seconds
        return seconds

    def to_hours(self):

        seconds = self.seconds * .001
        minutes = self.minutes * .01
        hours = self.hours + minutes + seconds
        return float(hours)

    def addSeconds(self,seconds):
        self.seconds = seconds + self.to_seconds
        return self.seconds 

    def plus(self,hours=0,minutes=0,seconds=0):
        time2 = Time(hours,minutes,seconds)
        total_seconds_time1 = self.to_seconds()
        total_seconds_time2 = self.to_seconds()
        total_seconds = total_seconds_time1 + total_seconds_time2
        newtime = total_seconds.clean()
        return newtime
    print()

