import time
class StopWatch:
      def __init__(self):
            self.__startTime = time.time().now()
            self.__endTime = None
      def getStartTime(self):
            return self.__startTime
      def getStopTime(self):
            return self.__endTime
      def start(self):
            self.__startTime=time.time().now()
      def stop(self):
            self.__endTime=time.time().now()
      def getElapsedTime(self):
            delta=(self.__endTime)-(self.__startTime)
            return delta * 1000
t1 =StopWatch()
t1.start()
t1.stop()
#elapsed=t1.getElapsedTime()
print(t1.getStartTime())

        
          