class Fan:
    
    def __init__(self, speed, on, radius, color):
        self.speed = speed
        self.on = on
        self.radius = radius
        self.color = color

    def getSpeed(self):
        return self.speed
        
    def getOn(self):
         return self.on
    
    def getRadius(self):
         return self.radius
    
    def getColor(self):
         return self.color

f1 = Fan("FAST", "on", "10", "yellow")        #Fan 1
f2 = Fan("SLOW", "off", "5", "blue")          #Fan 2

print("The speed of Fan 1 is:", f1.speed)
print("Fan 1 is:", f1.on)
print("The radius of Fan 1 is:", f1.radius)
print("The color of Fan 1 is:", f1.color)
print("The speed of Fan 2 is:", f2.speed)
print("Fan 2 is:", f2.on)
print("The radius of Fan 2 is:", f2.radius)
print("The color of Fan 2 is:", f2.color)