class Stock:
    def __init__(self, symbol, name, previousClosingPrice, currentPrice):
        self.symbol = symbol
        self.name = name
        self.previousClosingPrice = previousClosingPrice
        self.currentPrice = currentPrice

    
    def getSymbol(self):
        symbol = self.getSymbol
        return symbol
    
    def getName(self):
        name = self.name
        return name
     
    def getPreviousClosingprice(self):
        previousClosingPrice = self.previousClosingPrice
        return previousClosingPrice
    
    def getcurrentPrice(self):
        currentPrice = self.getcurrentPrice
        return currentPrice
    
    def getChangePercent(self):
       changePercent = (self.previousClosingPrice -self.currentPrice )*100/self.previousClosingPrice
       return changePercent
    
sym = str(input("Enter symbol: "))
n = str(input("Enter name: "))
pcp = float(input("Enter the previous closing price: "))
cp = float(input("Enter the current price: "))
chPer = (pcp -cp)*100/pcp

print("symbol: ", sym)
print("name: ", n)
print("previous closing price: ", pcp)
print("current price: ", cp)
print("The price-change percentage: ", chPer)