class Account:
    def __init__(self, id, balance, annualInterestRate):
        self.id = id
        self.balance = balance
        self.annualInterestRate = annualInterestRate
    
    def getId(self):
       id = self.id
       return id
    
    def getBalance(self):
        balance = self.balance
        return balance
       
    def getAnnualInterestRate(self):
        annualInterestRate = self.annualInterestRate
        return annualInterestRate
    
    def getMonthlyInterestRate(self):
        monthlyInterestRate = annualInterestRate / 12
        return monthlyInterestRate
    
    def getMonthlyInterest(self):
        monthlyInterest = balance * annualInterestRate / 12
        return monthlyInterest
    
    def withdraw(self, amount):
        if self.balance > 1:
            self.balance -= amount
                
    def deposit(self, amount):
        self.balance += amount

id = int(input("Enter id: "))
balance = float(input("Enter initial balance: "))
annualInterestRate = float(input("Enter annual interest rate: "))

print("id: ", id)
print("Beginning balance: ", balance)
print("Monthly interest rate: ",annualInterestRate / 12)
print("Monthly interest: ", balance * annualInterestRate / 12)